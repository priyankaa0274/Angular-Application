import { Directive, ElementRef, Input, HostListener } from '@angular/core';
import { ResultService } from './result.service';

@Directive({
  selector: '[appCalculateResult]'
})
export class CalculateResultDirective {

  @Input() v1;
  @Input() v2;
  result;
  // v1;
  // v2;
  constructor(private el: ElementRef, private _result: ResultService) { 
    console.log("Element ", el.nativeElement);
    // console.log("Values", this.v1, this.v2);
    
  }

  @HostListener('click') onclick() {
    console.log(this.v1);
    console.log(this.v2);
    console.log("Answer: ",this.v1 * this.v2);
    this.result = this.v1 * this.v2;

    this._result.res.next(this.result);
    this._result.sendResult({v1: this.v1, v2: this.v2, result: this.result})
    .subscribe((data: any) =>{
      console.log(data);
    })
  }


}
