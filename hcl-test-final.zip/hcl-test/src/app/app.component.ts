import { ResultService } from './result.service';
import { CalculateResultDirective } from './calculate-result.directive';
import { Values } from './values';
import { Component, ViewChild, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  values = { v1: parseInt(""), v2: parseInt("") };
  output: number;

  eV = parseInt("");
  // @ViewChild('mulForm') public mulform : NgForm;

  constructor(private _result: ResultService) { }
  ngOnInit() {
    this._result.getResult().subscribe((data: any) => {
      if (data.result) {
        this.values.v1 = data.result.value1;
        this.values.v2 = data.result.value2;
        this.output = data.result.result;
      }
    })

    this._result.res.subscribe((data) => {
      this.output = data;
    })
  }

  valdateFn(){
   if( !(this.values.v1 >= 0 && this.values.v2 >= 0)){
     return true;
   } else {
     return false;
   }
  }



  // @ViewChild('appCalculateResult') acr;


  // evaluateFn() {
  //   console.log("Values: ", this.values);
  //   if (!(parseInt(this.values.v1) >= 0)) {
  //     console.log("invalid");
  //     // set appCalculateResult(directive: CalculateResultDirective){
  //       this.acr.v1 = 7;
  //       this.acr.v2 = 9;
  //     // }
  //   } else {
  //     console.log("Valid");
  //   }
  // }
}
