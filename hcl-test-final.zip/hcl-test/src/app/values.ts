export interface Values {
    v1: number;
    v2: number;
}
