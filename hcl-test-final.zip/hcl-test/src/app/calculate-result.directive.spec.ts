import { CalculateResultDirective } from './calculate-result.directive';

describe('CalculateResultDirective', () => {
  it('should create an instance', () => {
    const directive = new CalculateResultDirective();
    expect(directive).toBeTruthy();
  });
});
