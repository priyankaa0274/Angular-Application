import { ResultService } from './result.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { CalculateResultDirective } from './calculate-result.directive'

@NgModule({
  declarations: [
    AppComponent,
    CalculateResultDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ResultService],
  bootstrap: [AppComponent]
})
export class AppModule { }
