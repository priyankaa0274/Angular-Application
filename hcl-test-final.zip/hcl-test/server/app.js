const express = require('express'),
  app = express(),
  bodyParser = require('body-parser'),
  mongoose = require('mongoose'),
  cors = require('cors');


app.use(bodyParser.json());
app.use(cors());

mongoose.connect('mongodb://localhost/HCLDB');
const db = mongoose.connection;

db.on('error', () => {
  console.log("Connection with DB failed")
});

db.on('open', () => {
  console.log("Connection with DB established")
});


app.get('/', function(req, res) {
  res.sendFile(__dirname+'/dist/index.html');
})

const Result = mongoose.model('results', {
  
  values: [{
    value1: {
      type: Number,
      required: true
    },
    value2: {
      type: Number,
      required: true
    },
    result: {
      type: Number,
      required: true
    }
  }]
});


app.post('/saveData', (req, res) => {
  
 

  Result.find({}, (err, docs1) => {
    console.log(docs1);
    if (docs1.length == 0) {
      console.log("Inside if")
      let r1 = new Result({
        values: [{value1: req.body.v1, value2: req.body.v2, result: req.body.result}]
      })

      r1.save((err) => {
        res.json({
          success: true
        })
      })
    } else {
      Result.findOneAndUpdate({}, {
        $push: {
          "values": {
            value1: parseInt(req.body.v1),
            value2: parseInt(req.body.v2),
            result: parseInt(req.body.result)
          }
        }
      }, (err, docs) => {
        
          res.json({
            success: true
          })
        
      })
    }

  });

});

app.get('/getData', (req, res) => {
  Result.find({}, (err, docs) => {
    if (docs != [] && docs.length > 0) {
      res.json({
        result: docs[0]["values"][docs[0]["values"].length - 1]
      });
    } else {
      res.json({
        result: null
      })
    }

  })
})

app.listen(3000, () => {
  console.log("Server running on localhost:3000");
})
